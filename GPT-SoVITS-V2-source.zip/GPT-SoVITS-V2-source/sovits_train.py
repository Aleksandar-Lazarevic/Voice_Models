import os,shutil,sys,pdb,re
import json,yaml,warnings,torch
import platform
import psutil
import signal

now_dir = os.getcwd()
sys.path.insert(0, now_dir)

tmp = os.path.join(now_dir, "TEMP")
os.makedirs(tmp, exist_ok=True)
os.environ["TEMP"] = tmp
if(os.path.exists(tmp)):
    for name in os.listdir(tmp):
        if(name=="jieba.cache"):continue
        path="%s/%s"%(tmp,name)
        delete=os.remove if os.path.isfile(path) else shutil.rmtree
        try:
            delete(path)
        except Exception as e:
            print(str(e))
            pass

from tools import my_utils
import traceback
import shutil
import pdb
import gradio as gr
from subprocess import Popen
import signal
from config import python_exec,infer_device,is_half,exp_root,webui_port_main,webui_port_infer_tts,webui_port_uvr5,webui_port_subfix,is_share
from tools.i18n.i18n import I18nAuto
i18n = I18nAuto()
from scipy.io import wavfile
from tools.my_utils import load_audio
from multiprocessing import cpu_count
import argparse

parser = argparse.ArgumentParser(description="SoVITS Train")
parser.add_argument('--name', required=True, help="exp_name")
parser.add_argument('--half', required=True, help="is_half")
parser.add_argument('--batch_size', type=int, required=True, help="batch size")
parser.add_argument('--total_epoch', type=int, required=True, help="total epoch")

args = parser.parse_args()

SoVITS_weight_root="SoVITS_weights"
GPT_weight_root="GPT_weights"
p_train_SoVITS=None

batch_size=args.batch_size
total_epoch=args.total_epoch
exp_name = args.name
text_low_lr_rate=0.4
if_save_latest = True
if_save_every_weights =True
save_every_epoch = 4
gpu_numbers1Ba = 1
pretrained_s2G="GPT_SoVITS/pretrained_models/gsv-v2final-pretrained/s2G2333k.pth"
pretrained_s2D="GPT_SoVITS/pretrained_models/gsv-v2final-pretrained/s2D2333k.pth"

if(p_train_SoVITS==None):
    with open("GPT_SoVITS/configs/s2.json")as f:
        data=f.read()
        data=json.loads(data)
    s2_dir="GPT_SoVITS/%s/%s"%(exp_root,exp_name)
    os.makedirs("%s/logs_s2"%(s2_dir),exist_ok=True)
    if(is_half==False):
        data["train"]["fp16_run"]=False
        batch_size=max(1,batch_size//2)
    data["train"]["batch_size"]=batch_size
    data["train"]["epochs"]=total_epoch
    data["train"]["text_low_lr_rate"]=text_low_lr_rate
    data["train"]["pretrained_s2G"]=pretrained_s2G
    data["train"]["pretrained_s2D"]=pretrained_s2D
    data["train"]["if_save_latest"]=if_save_latest
    data["train"]["if_save_every_weights"]=if_save_every_weights
    data["train"]["save_every_epoch"]=save_every_epoch
    data["train"]["gpu_numbers"]=gpu_numbers1Ba
    data["data"]["exp_dir"]=data["s2_ckpt_dir"]=s2_dir
    data["save_weight_dir"]=SoVITS_weight_root
    data["name"]=exp_name
    tmp_config_path="%s/tmp_s2.json"%tmp
    with open(tmp_config_path,"w")as f:f.write(json.dumps(data))

    cmd = '"%s" GPT_SoVITS/s2_train.py --config "%s"'%(python_exec,tmp_config_path)
    #yield "SoVITS训练开始：%s"%cmd,{"__type__":"update","visible":False},{"__type__":"update","visible":True}
    print(cmd)
    p_train_SoVITS = Popen(cmd, shell=True)
    p_train_SoVITS.wait()
    p_train_SoVITS=None
    #yield "SoVITS训练完成",{"__type__":"update","visible":True},{"__type__":"update","visible":False}
#else:
    #yield "已有正在进行的SoVITS训练任务，需先终止才能开启下一次任务",{"__type__":"update","visible":False},{"__type__":"update","visible":True}